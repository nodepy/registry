
migrate.add_field('user', 'superuser', False)
